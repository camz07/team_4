	</body>
	<!-- Link scripts here -->
	<script src=<?php echo base_url("themes/jquery-2.0.3.min.js"); ?>></script>
</html>