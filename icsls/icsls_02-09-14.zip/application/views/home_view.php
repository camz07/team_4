<?=$this->load->view("includes/header")?>
	
	<!-- Insert contents here -->
		
<?=$this->load->view("includes/footer")?>