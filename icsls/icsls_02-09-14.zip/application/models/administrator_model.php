<?php

include('user_model.php');

class Administrator_model extends User_model{

}

?>